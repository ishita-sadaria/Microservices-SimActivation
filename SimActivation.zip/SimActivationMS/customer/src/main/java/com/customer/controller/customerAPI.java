package com.customer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.dto.CustomerBasicDetailsDTO;
import com.customer.dto.CustomerDTO;
import com.customer.service.CustomerService;
import com.simActivation.Exception.CustomerNotFoundException;

@RestController
@RequestMapping("/customer")
public class customerAPI {

	@Autowired
	CustomerService custService;
	
	@GetMapping("/address/{uniqueIdNumber}")
	public String getAddressId(@PathVariable String uniqueIdNumber) {
		return custService.getAddressId(uniqueIdNumber);
	}
	
	@GetMapping("/identity/{uniqueIdNumber}")
	public CustomerDTO getCustomer(@PathVariable String uniqueIdNumber) {
		return custService.getCustomer(uniqueIdNumber);
	}
	@GetMapping("/validate/{email}")
	public CustomerBasicDetailsDTO getCustomerBasic(@PathVariable String email)throws CustomerNotFoundException{
		return custService.getCustomerBasic(email);
	}
	
}
