package com.customer.dto;


import java.sql.Date;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;


public class CustomerIdentityDTO {
	@Size(max=15,message="Firstname/Lastname should be maximum of 15 characters")
	@Pattern(regexp = "^[a-zA-Z]+$", message="Firstname/Lastname should be maximum of 15 characters")
	private String firstName;
	
	@Size(max=15,message="Firstname/Lastname should be maximum of 15 characters")
	@Pattern(regexp = "^[a-zA-Z]+$", message="Firstname/Lastname should be maximum of 15 characters")
	private String lastName;
	
	@Size(min = 16, max=16, message="Unique Id Number Should be of 16 digits")
	private String uniqueIdNumber;
	
	@DateTimeFormat(pattern="YYYY-MM-DD")
	private Date date;
	public CustomerIdentityDTO() {}
	public CustomerIdentityDTO(String firstName,String lastName, String uniqueIdNumber) {
		super();
		this.firstName=firstName;
		this.lastName = lastName;
		this.uniqueIdNumber = uniqueIdNumber;
	}
	public CustomerIdentityDTO(String firstName,String lastName, String uniqueIdNumber,Date date) {
		super();
		this.firstName=firstName;
		this.lastName = lastName;
		this.uniqueIdNumber = uniqueIdNumber;
		this.date=date;
	}
	public Date getDate() {
		return date;
	}
	@Override
	public String toString() {
		return "CustomerIdentityDTO [firstName=" + firstName + ", lastName=" + lastName + ", uniqueIdNumber="
				+ uniqueIdNumber + ", date=" + date + "]";
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}
	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}
	
}
