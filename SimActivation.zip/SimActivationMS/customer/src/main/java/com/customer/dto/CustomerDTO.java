package com.customer.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.validation.constraints.Email;

public class CustomerDTO {

	private Date dateOfBirth;
	private String first_name;
	private String last_name;
	private int simId;
	public CustomerDTO(Date dateOfBirth, String first_name, String last_name, int simId) {
		super();
		this.dateOfBirth = dateOfBirth;
		this.first_name = first_name;
		this.last_name = last_name;
		this.simId = simId;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public int getSimId() {
		return simId;
	}
	public void setSimId(int simId) {
		this.simId = simId;
	}
	@Override
	public String toString() {
		return "CustomerDTO [dateOfBirth=" + dateOfBirth + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", simId=" + simId + "]";
	}
	public CustomerDTO() {
		super();
	}
	
	
	
}
