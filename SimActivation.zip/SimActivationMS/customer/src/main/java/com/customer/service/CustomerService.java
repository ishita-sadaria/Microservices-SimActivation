package com.customer.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.dto.CustomerBasicDetailsDTO;
import com.customer.dto.CustomerDTO;
import com.customer.entity.Customer;
import com.customer.repo.CustomerRepo;
import com.simActivation.Exception.CustomerNotFoundException;

@Service
public class CustomerService {
	@Autowired
	CustomerRepo custDB;
	
	public String getAddressId(String uniqueIdNumber) {
		return custDB.findByUniqueIdNumber(uniqueIdNumber);
	}
	
	public CustomerDTO getCustomer(String uniqueIdNumber) {
		Customer customer = custDB.findByUniqueIdNumberStatus(uniqueIdNumber).get();
		return Customer.prepareCustomerDTO(customer);
	}
	
	public CustomerBasicDetailsDTO getCustomerBasic(String email) throws CustomerNotFoundException{
		Optional<Customer> customer = custDB.findById(email);
		if(customer.isPresent()) {
			Customer cust = customer.get();
			return Customer.prepareCustomerBasicDetailsDTO(cust);
		}
		else throw new CustomerNotFoundException("No Customer Found for Given Details");
	}
	
}
