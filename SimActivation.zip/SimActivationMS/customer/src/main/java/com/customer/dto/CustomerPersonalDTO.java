package com.customer.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class CustomerPersonalDTO {
	@Size(max=15,message="Firstname/Lastname should be maximum of 15 characters")
	@Pattern(regexp = "^[a-zA-Z]+$", message="Firstname/Lastname should be maximum of 15 characters")
	private String firstName;
	
	@Size(max=15,message="Firstname/Lastname should be maximum of 15 characters")
	@Pattern(regexp = "^[a-zA-Z]+$", message="Firstname/Lastname should be maximum of 15 characters")
	private String lastName;
	
	@Email(message = "Invalid Email")
	private String email;
	
	public CustomerPersonalDTO(){}

	
	public CustomerPersonalDTO(String firstName, String lastName, String email) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	@Override
	public String toString() {
		return "CustomerPersonalDTO [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + "]";
	}
	
	
}
