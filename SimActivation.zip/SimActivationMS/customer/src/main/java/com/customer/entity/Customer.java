package com.customer.entity;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;

import com.customer.dto.CustomerBasicDetailsDTO;
import com.customer.dto.CustomerDTO;
import com.customer.dto.CustomerIdentityDTO;

@Entity
public class Customer {
	@Column(name="unique_id_number")
	private String uniqueIdNumber;
	
	@Column(name="date_of_birth")
	private Date dateOfBirth;
	
	@Id
	@Column(name="email_address")
	@Email
	private String email;
	
	@Column(name="first_name")
	private String first_name;
	
	@Column(name="last_name")
	private String last_name;
	
	@Column(name="id_type")
	private String idType;
	
	@Column(name="customer_address_addressid")
	private int customerAddressId;
	
	@Column(name="sim_id")	private int simId;
	
	private String state;

	public Customer() {}	
	
	public Customer(String uniqueIdNumber, Date dateOfBirth, String email, String first_name, String last_name,
			String idType, int customerAddressId, int simId, String state) {
		super();
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.first_name = first_name;
		this.last_name = last_name;
		this.idType = idType;
		this.customerAddressId = customerAddressId;
		this.simId = simId;
		this.state = state;
	}

	@Override
	public String toString() {
		return "Customer [uniqueIdNumber=" + uniqueIdNumber + ", dateOfBirth=" + dateOfBirth + ", email=" + email
				+ ", first_name=" + first_name + ", last_name=" + last_name + ", idType=" + idType
				+ ", customerAddressId=" + customerAddressId + ", simId=" + simId + ", state=" + state + "]";
	}
	

	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}

	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public int getCustomerAddressId() {
		return customerAddressId;
	}

	public void setCustomerAddressId(int customerAddressId) {
		this.customerAddressId = customerAddressId;
	}

	public int getSimId() {
		return simId;
	}

	public void setSimId(int simId) {
		this.simId = simId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	 public static CustomerDTO prepareCustomerDTO(Customer cus) {
		 CustomerDTO customer = new CustomerDTO();
		 customer.setDateOfBirth(cus.getDateOfBirth());
		 customer.setFirst_name(cus.getFirst_name());
		 customer.setLast_name(cus.getLast_name());
		 customer.setSimId(cus.getSimId());
		 return customer;
	 }
	 public static CustomerBasicDetailsDTO prepareCustomerBasicDetailsDTO(Customer cus) {
		 CustomerBasicDetailsDTO customer = new CustomerBasicDetailsDTO();
		 customer.setDateOfBirth(cus.getDateOfBirth());
		 customer.setEmail(cus.getEmail());
		 return customer;
	 }
	
	
}
