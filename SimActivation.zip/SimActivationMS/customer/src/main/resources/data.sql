
INSERT INTO Customer(unique_id_number,date_of_birth,email_address,first_name,last_name,id_type,customer_address_addressid,sim_id,state)VALUES
('1234567891234567','1990-12-12','smith@abc.com','smith','john','Aadhar',1,1,'Karnataka'),
('1234567891234568','1998-12-12','bob@abc.com','Bob','Sam','Aadhar',2,2,'Karnataka');
