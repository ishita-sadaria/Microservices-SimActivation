
INSERT INTO CustomerAddress(address_id,address,city,pincode,state)VALUES
(1,'Jayanagar','Bangalore',560041,'Karnataka'),
(2,'Vijaynagar','Mysore',567017,'Karnataka');

