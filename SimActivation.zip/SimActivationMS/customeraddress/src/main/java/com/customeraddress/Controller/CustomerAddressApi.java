package com.customeraddress.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.customeraddress.DTO.CustomerAddressDTO;
import com.customeraddress.service.CustomerAddressService;
import com.simActivation.Exception.CustomerNotFoundException;

@RestController
@RequestMapping("/update")
public class CustomerAddressApi {

	@Autowired
	CustomerAddressService custService;
	@PostMapping
	public CustomerAddressDTO updateAddress(@Valid @RequestBody CustomerAddressDTO cus)throws CustomerNotFoundException {
		return custService.updateAddress(cus); 
	}
	
}
