package com.customeraddress.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.customeraddress.DTO.CustomerAddressDTO;


@Entity
public class Customeraddress {

	@Id
	@Column(name="address_id")
	private String addressId;
	@Column(name="address")
	private String address;
	@Column(name="city")
	private String city;
	@Column(name="state")
	private String state;
	@Column(name="pincode")
	private String pincode;
	
//	@OneToOne(targetEntity = Customer.class,cascade = CascadeType.ALL)
//	@JoinColumn(name="AC_FK", referencedColumnName = "customer_address_addressid")
//	private Customer cus;
	
	public Customeraddress() {}
	public Customeraddress(String addressId, String address, String city, String state, String pincode) {
		super();
		this.addressId = addressId;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}
	public String getAddressId() {
		return addressId;
	}
	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Customeraddress [addressId=" + addressId + ", address=" + address + ", city=" + city + ", state="
				+ state + ", pincode=" + pincode + "]";
	}
	public static CustomerAddressDTO prepareCustomerAddressDTO(Customeraddress cus,String uniqueIdNumber) {
		CustomerAddressDTO c = new CustomerAddressDTO();
		c.setAddress(cus.getAddress());
		c.setCity(cus.getCity());
		c.setPincode(cus.getPincode());
		c.setState(cus.getState());
		c.setUniqueIdNumber(uniqueIdNumber);
		return c;
	}
	
	
}
