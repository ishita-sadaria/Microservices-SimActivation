package com.customeraddress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomeraddressApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomeraddressApplication.class, args);
	}

}
