package com.customeraddress.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.customeraddress.DTO.CustomerAddressDTO;
import com.customeraddress.entity.Customeraddress;
import com.customeraddress.repo.CustomerAddressRepo;
import com.simActivation.Exception.CustomerNotFoundException;



@Service
public class CustomerAddressService {
	
	@Autowired
	CustomerAddressRepo custDB;
	
	@Autowired
	DiscoveryClient client;
	
	
	public CustomerAddressDTO updateAddress(CustomerAddressDTO cust) throws CustomerNotFoundException {
		
		String UNI = cust.getUniqueIdNumber();
		
		List<ServiceInstance> c =  client.getInstances("customer");
		
		if(c==null || c.isEmpty()) {
			throw new CustomerNotFoundException("No SIM Registered with the given Unique Id Number");
		}
		String uri = c.get(0).getUri() + "/customer/address/" + UNI;
		String addressId = new RestTemplate().getForObject(uri, String.class);
		
		if(addressId==null) {
			throw new CustomerNotFoundException("No SIM Registered with the given Unique Id Number");
		}
		//Not providing Entity Object
		else {
			Customeraddress customer = CustomerAddressDTO.prepareCustomeraddress(cust, addressId);
			return Customeraddress.prepareCustomerAddressDTO(custDB.saveAndFlush(customer),cust.getUniqueIdNumber());			
		}
	}
	
	
}
