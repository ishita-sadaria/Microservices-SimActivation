package com.customeraddress.DTO;

import javax.persistence.Column;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.customeraddress.entity.Customeraddress;


public class CustomerAddressDTO {
	@Size(max=16,min=16,message="Unique Id Number should be of 16 digits")
	private String uniqueIdNumber;
	
	@Size(max=25,message="Address should be maximum of 25 characters")
	private String address;
	
	@Pattern(regexp = "^[A-Za-z0-9 ]+$",message="Name of the City should not contain any special characters")
	private String city;
	
	@Pattern(regexp = "^[A-Za-z0-9 ]+$",message="Name of the State should not contain any special characters")
	private String state;
	
	@Size(min=6,max=6,message="Pin should be 6 digit number")
	private String pincode;
	
	public CustomerAddressDTO(String uniqueIdNumber, String address, String city, String state, String pincode) {
		super();
		this.uniqueIdNumber = uniqueIdNumber;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}
	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber=uniqueIdNumber;
	}
	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	public CustomerAddressDTO() {}
	public static Customeraddress prepareCustomeraddress(CustomerAddressDTO cus,String addressId) {
		Customeraddress c = new Customeraddress();
		c.setAddressId(addressId);
		c.setAddress(cus.getAddress());
		c.setCity(cus.getCity());
		c.setPincode(cus.getPincode());
		c.setState(cus.getState());
		return c;
	}
	@Override
	public String toString() {
		return "CustomerAddressDTO [uniqueIdNumber=" + uniqueIdNumber + ", address=" + address + ", city=" + city
				+ ", state=" + state + ", pincode=" + pincode + "]";
	}
	
	
}
