package com.customeraddress.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.customeraddress.entity.Customeraddress;


public interface CustomerAddressRepo extends JpaRepository<Customeraddress, String> {
	
}
