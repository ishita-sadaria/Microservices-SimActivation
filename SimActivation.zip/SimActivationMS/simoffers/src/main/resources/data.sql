

INSERT INTO SIMOFFERS(offer_id,call_qty,cost,data_qty,duration,offer_name,sim_id) VALUES 
(1,100,100,120,10,'Free Calls and data',1),
(2,150,50,100,15,'Free Calls',2);

