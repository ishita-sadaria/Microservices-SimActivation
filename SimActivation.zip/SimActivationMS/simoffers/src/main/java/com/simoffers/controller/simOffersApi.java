package com.simoffers.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.simoffers.DTO.simOffersDTO;
import com.simoffers.service.simOffersService;

@RestController
public class simOffersApi {
	
	@Autowired
	simOffersService offerService;
	
	@GetMapping("/offer/{simId}")
	public simOffersDTO getOffers(@PathVariable int simId) {
		return offerService.getOffer(simId);
	}
	
}
