package com.simoffers.Exception;

public class InvalidSimDetailsException extends Exception {
	
	public InvalidSimDetailsException(String errors) {
		super(errors);
	}

}
