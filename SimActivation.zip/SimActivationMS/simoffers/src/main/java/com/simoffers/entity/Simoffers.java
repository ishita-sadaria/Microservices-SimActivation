package com.simoffers.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.simoffers.DTO.simOffersDTO;

@Entity
public class Simoffers {
	@Column(name="offer_id")
	private Integer offerId;
	@Column(name="call_qty")
	private Integer callQty;
	
	@Column(name="cost")
	private Integer Cost;
	
	@Column(name="data_qty")
	private Integer dataQty;
	
	@Column(name="duration")
	private Integer duration;
	
	@Column(name="offer_name")
	private String OfferName;
	
	@Id
	@Column(name="sim_id")
	private Integer SimId;
	
	@Override
	public String toString() {
		return "SimOffers [offerId=" + offerId + ", callQty=" + callQty + ", Cost=" + Cost + ", dataQty=" + dataQty
				+ ", duration=" + duration + ", OfferName=" + OfferName + ", SimId=" + SimId + "]";
	}
	
	public Simoffers() {}
	public Simoffers(Integer offerId, Integer callQty, Integer cost, Integer dataQty, Integer duration,
			String offerName, Integer simId) {
		super();
		this.offerId = offerId;
		this.callQty = callQty;
		Cost = cost;
		this.dataQty = dataQty;
		this.duration = duration;
		OfferName = offerName;
		SimId = simId;
	}

	public Integer getOfferId() {
		return offerId;
	}

	public void setOfferId(Integer offerId) {
		this.offerId = offerId;
	}

	public Integer getCallQty() {
		return callQty;
	}

	public void setCallQty(Integer callQty) {
		this.callQty = callQty;
	}

	public Integer getCost() {
		return Cost;
	}

	public void setCost(Integer cost) {
		Cost = cost;
	}

	public Integer getDataQty() {
		return dataQty;
	}

	public void setDataQty(Integer dataQty) {
		this.dataQty = dataQty;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getOfferName() {
		return OfferName;
	}

	public void setOfferName(String offerName) {
		OfferName = offerName;
	}

	public Integer getSimId() {
		return SimId;
	}

	public void setSimId(Integer simId) {
		SimId = simId;
	}
	public static simOffersDTO prepareSimOffersDTO(Simoffers offer) {
		simOffersDTO offerDTO = new simOffersDTO();
		offerDTO.setCallQty(offer.getCallQty());
		offerDTO.setCost(offer.getCost());
		offerDTO.setDataQty(offer.getDataQty());
		offerDTO.setDuration(offer.getDuration());
		offerDTO.setOfferName(offer.getOfferName());
		return offerDTO;
		
	}

	
}
