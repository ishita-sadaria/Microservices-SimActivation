package com.simoffers.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simoffers.DTO.simOffersDTO;
import com.simoffers.entity.Simoffers;
import com.simoffers.repo.SimOffersRepo;

@Service
public class simOffersService {
	
	@Autowired
	SimOffersRepo simofferDB;
	
	public simOffersDTO getOffer(int simId) {
		Simoffers simoffer =  simofferDB.findById(simId).get();
		return Simoffers.prepareSimOffersDTO(simoffer);
	}
}
