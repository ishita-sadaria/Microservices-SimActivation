package com.simoffers.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.simoffers.entity.Simoffers;


public interface SimOffersRepo extends JpaRepository<Simoffers,Integer> {
	
}
