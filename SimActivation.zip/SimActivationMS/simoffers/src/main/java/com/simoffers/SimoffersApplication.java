package com.simoffers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimoffersApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimoffersApplication.class, args);
	}

}
