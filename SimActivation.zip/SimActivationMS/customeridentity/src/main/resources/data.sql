
INSERT INTO CUSTOMERIDENTITY(unique_id_number,date_of_birth,first_name,last_name,email_address,state)VALUES
('1234567891234567','1990-12-12','smith','john','smith@abc.com','Karnataka'),
('1234567891234568','1998-12-12','Bob','Sam','bob@abc.com','Karnataka');
