package com.customeridentity.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.customeridentity.entity.Customeridentity;


public interface CustomerIdentityRepo extends JpaRepository<Customeridentity, String> {
//	Optional<CustomerIdentity>findByCus;
	
//	@Query("select * from CUSTOMERIDENTITY c where c.first_name = ?1", native_query=true)
//	Optional<Customeridentity>findByFirstNameAndLastName(String firstName,String lastName);
	
	@Query(nativeQuery=true,value="Select c.email_address from Customeridentity c "
			+ "where c.first_name=?1 and c.last_name=?2")
	String findByFirstNameAndLastName(String firstName,String lastName);
}
