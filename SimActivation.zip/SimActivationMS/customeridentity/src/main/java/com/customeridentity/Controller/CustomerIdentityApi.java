package com.customeridentity.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customeridentity.DTO.CustomerBasicDetailsDTO;
import com.customeridentity.DTO.CustomerIdentityDTO;
import com.customeridentity.DTO.CustomerPersonalDTO;
import com.customeridentity.service.CustomerIdentityService;
import com.simActivation.Exception.CustomerNotFoundException;
import com.simActivation.Exception.InvalidSimDetailsException;

@RestController
@RequestMapping("/validate")
public class CustomerIdentityApi {
	
	@Autowired
	CustomerIdentityService custService;
	
	@PostMapping("personal")
	public String validatePersonalDetails(@Valid @RequestBody CustomerPersonalDTO cus, Errors errors) throws InvalidSimDetailsException {
		if(errors.hasErrors())
		{
			return errors.getAllErrors().toString();
		}
		else {
			return custService.validatePersonalDetails(cus);			
		}
	}
	
	
	@PostMapping("identity")
	public String validateIdentity(@Valid @RequestBody CustomerIdentityDTO cus,Errors errors) throws InvalidSimDetailsException {
		if(errors.hasErrors())
		{
			return errors.getAllErrors().toString();
		}
		else {
			return custService.validateIdentity(cus);			
		}
	}
	@PostMapping("basic")
	public String ValidateCustomerBasic(@Valid @RequestBody CustomerBasicDetailsDTO customer)throws CustomerNotFoundException {
		return custService.validateCustomerBasic(customer.getEmail(), customer.getDateOfBirth());
	}
}
