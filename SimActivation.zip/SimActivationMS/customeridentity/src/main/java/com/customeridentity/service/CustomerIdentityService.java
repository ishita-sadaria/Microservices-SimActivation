package com.customeridentity.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.customeridentity.DTO.CustomerBasicDetailsDTO;
import com.customeridentity.DTO.CustomerDTO;
import com.customeridentity.DTO.CustomerIdentityDTO;
import com.customeridentity.DTO.CustomerPersonalDTO;
import com.customeridentity.repo.CustomerIdentityRepo;
import com.simActivation.Exception.CustomerNotFoundException;
import com.simActivation.Exception.InvalidSimDetailsException;

@Service
public class CustomerIdentityService {
	@Autowired
	CustomerIdentityRepo custDB;
	@Autowired
	DiscoveryClient client;
	
	
	public String validatePersonalDetails(CustomerPersonalDTO cus) throws InvalidSimDetailsException {
		String email = custDB.findByFirstNameAndLastName(cus.getFirstName(),cus.getLastName());
		if(email.equals(cus.getEmail())) {
			return "Validation Successful";
		}
		else throw new InvalidSimDetailsException("Incorrect Details");
	}
	
	public String validateIdentity(CustomerIdentityDTO cus) throws InvalidSimDetailsException{
		List<ServiceInstance> list = client.getInstances("customer");
		if(list!=null && !list.isEmpty()) {
			String uri = list.get(0).getUri() + "/customer/identity/"+cus.getUniqueIdNumber();
			CustomerDTO customer = new RestTemplate().getForObject(uri, CustomerDTO.class);
			LocalDate d1 = customer.getDateOfBirth().toLocalDate();
			LocalDate d2 = cus.getDate().toLocalDate();
			boolean flag = d1.isEqual(d2);
			if(flag && cus.getFirstName().equals(customer.getFirst_name())
					&& cus.getLastName().equals(customer.getLast_name())) {
				//need not to check if sim is active or not as it is done in simActivationService
				String uri2 = "http://localhost:9001/offers/" + customer.getSimId();
				return new RestTemplate().getForObject(uri2,String.class);
			}
			else throw new InvalidSimDetailsException("Invalid Credentials");
		}
		else {
			throw new InvalidSimDetailsException("Invalid Credentials");
		}
	}
	
	public String validateCustomerBasic(String email,Date dateOfBirth) throws CustomerNotFoundException{
		List<ServiceInstance> list = client.getInstances("customer");
		if(list!=null && !list.isEmpty()) {
			String uri = list.get(0).getUri() + "/customer/validate/"+email;
			CustomerBasicDetailsDTO customer = new RestTemplate().getForObject(uri, CustomerBasicDetailsDTO.class);
			LocalDate d1 = dateOfBirth.toLocalDate();
			LocalDate d2 = customer.getDateOfBirth().toLocalDate();
			if(d1.isEqual(d2) && customer.getEmail().equals(email)) {
				return "Success";
			}
			else throw new CustomerNotFoundException("No Request Placed For You");			
		}
		else throw new CustomerNotFoundException("No Request Placed For You");	
	}
}
