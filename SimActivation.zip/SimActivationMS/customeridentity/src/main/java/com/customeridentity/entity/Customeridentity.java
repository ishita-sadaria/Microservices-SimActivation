package com.customeridentity.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;




@Entity
public class Customeridentity {
	@Column(name="first_name")
	private String firstName;
	@Column(name="last_name")
	private String lastName;
	@Id
	@Column(name="unique_id_number")
	private String uniqueIdNumber;
	@Column(name="date_of_birth")
	private Date dateOfBirth;
	@Column(name="email_address")
	private String email;
	@Column(name="state")
	private String state;
	public Customeridentity() {}
	public Customeridentity(String firstName, String lastName, String uniqueIdNumber, Date dateOfBirth, String email,
			String state) {
		super();
		this.firstName = firstName;
		lastName = lastName;
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.state = state;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		lastName = lastName;
	}
	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}
	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Customeridentity [firstName=" + firstName + ", LastName=" + lastName + ", uniqueIdNumber="
				+ uniqueIdNumber + ", dateOfBirth=" + dateOfBirth + ", email=" + email + ", state=" + state + "]";
	}
	
//	public static CustomerIdentityDTO prepareCustomerIdentity(CustomerIdentity cus) {
//		CustomerIdentityDTO customer = new CustomerIdentityDTO();
//		customer.setCus(cus.getCus());
//		customer.setDateOfBirth(cus.getDateOfBirth());
//		customer.setEmail(cus.getEmail());
//		customer.setState(cus.getState());
//		customer.setUniqueIdNumber(cus.getUniqueIdNumber());
//		return customer;
//		
//	}
	
	
}
