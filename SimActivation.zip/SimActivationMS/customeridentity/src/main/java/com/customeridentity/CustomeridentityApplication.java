package com.customeridentity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomeridentityApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomeridentityApplication.class, args);
	}

}
