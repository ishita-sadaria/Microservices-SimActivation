package com.customeridentity.DTO;

import java.sql.Date;

import javax.validation.constraints.Email;

import org.springframework.format.annotation.DateTimeFormat;

public class CustomerBasicDetailsDTO {
	@DateTimeFormat(pattern = "YYYY-MM-DD")
	private Date dateOfBirth;
	@Email
	private String email;
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public CustomerBasicDetailsDTO() {};
	public CustomerBasicDetailsDTO(Date dateOfBirth, String email) {
		super();
		this.dateOfBirth = dateOfBirth;
		this.email = email;
	}
	
	
}
