INSERT INTO SIMDETAILS(sim_id, service_number, sim_number, sim_status) VALUES 
(1,'1234567891','1234567891234','active'),
(2,'1234567892','1234567891235','inactive');

