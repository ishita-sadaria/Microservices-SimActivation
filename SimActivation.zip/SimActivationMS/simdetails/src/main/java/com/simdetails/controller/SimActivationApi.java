package com.simdetails.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.simdetails.DTO.SimDetailsDTO;
import com.simdetails.Exception.InvalidSimDetailsException;
import com.simdetails.service.SimActivationService;



//first one

@RestController
@RequestMapping("/offers")
public class SimActivationApi {
	@Autowired
	SimActivationService simService;
	
	@PostMapping
	public String getOffers(@Valid @RequestBody SimDetailsDTO sim) throws InvalidSimDetailsException {	
		return simService.getOffers(sim.getServiceNumber(),sim.getSimNumber());
	}
	
	@GetMapping("/{simId}")
	public String activateSim(@PathVariable int simId) {
		return simService.activateSim(simId);
	}
}
