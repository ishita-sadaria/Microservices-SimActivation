package com.simdetails.DTO;

import javax.validation.constraints.Size;

import com.simdetails.entity.Simdetails;


public class SimDetailsDTO {
	@Size(min=10,max=10,message = "Service Number Should be of 10 digits")
	private String serviceNumber;
	@Size(min=13,max=13, message = "SIM number should be of 12 digits")
	private String simNumber;
	public SimDetailsDTO(){}
	public SimDetailsDTO(String serviceNumber, String simNumber) {
		super();
		this.serviceNumber = serviceNumber;
		this.simNumber = simNumber;
	}
	public String getServiceNumber() {
		return serviceNumber;
	}
	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = serviceNumber;
	}
	public String getSimNumber() {
		return simNumber;
	}
	public void setSimNumber(String simNumber) {
		this.simNumber = simNumber;
	}
	

	
	@Override
	public String toString() {
		return "SimDetailsDTO [serviceNumber=" + serviceNumber + ", simNumber=" + simNumber + "]";
	}
	public static Simdetails prepareSimDetailsEntity(SimDetailsDTO simDTO) {
		Simdetails sim = new Simdetails();
		sim.setServiceNumber(simDTO.serviceNumber);
		sim.setSimNumber(simDTO.serviceNumber);
		return sim;
		
	}
}
