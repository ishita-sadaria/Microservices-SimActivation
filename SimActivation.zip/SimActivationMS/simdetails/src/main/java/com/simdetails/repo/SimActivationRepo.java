package com.simdetails.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.simdetails.entity.Simdetails;

public interface SimActivationRepo extends JpaRepository<Simdetails, String>{

	Optional<Simdetails> findBySimId(int simId);
	
	 
	
}