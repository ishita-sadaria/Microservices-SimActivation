package com.simdetails.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.simdetails.DTO.SimDetailsDTO;



//Validation and Error handling is Left

@Entity
public class Simdetails {

	@Id
	@Column(name = "service_number")
	private String serviceNumber;

	@Column(name = "sim_number")
	private String simNumber;

	@Column(name = "sim_id")
	private int simId;

	@Column(name = "sim_status")
	private String simStatus;

	public Simdetails() {
	}

	public Simdetails(String serviceNumber, String simNumber, int simId, String simStatus) {
		super();
		this.serviceNumber = serviceNumber;
		this.simNumber = simNumber;
		this.simId = simId;
		this.simStatus = simStatus;
	}

	

	public String getServiceNumber() {
		return serviceNumber;
	}

	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = serviceNumber;
	}

	public String getSimNumber() {
		return simNumber;
	}

	public void setSimNumber(String simNumber) {
		this.simNumber = simNumber;
	}

	public int getSimId() {
		return simId;
	}

	public void setSimId(int simId) {
		this.simId = simId;
	}

	public String getSimStatus() {
		return simStatus;
	}

	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}

	public static SimDetailsDTO prepareSimDetailsDTO(Simdetails sim) {
		SimDetailsDTO simDTO = new SimDetailsDTO();
		simDTO.setServiceNumber(sim.serviceNumber);
		simDTO.setSimNumber(sim.simNumber);
		return simDTO;
	}

	@Override
	public String toString() {
		return "Simdetails [serviceNumber=" + serviceNumber + ", simNumber=" + simNumber + ", simId=" + simId
				+ ", simStatus=" + simStatus + "]";
	}
}
