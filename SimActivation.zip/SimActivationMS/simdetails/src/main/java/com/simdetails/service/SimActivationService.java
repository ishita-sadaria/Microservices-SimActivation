package com.simdetails.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.simdetails.DTO.simOffersDTO;
import com.simdetails.Exception.InvalidSimDetailsException;
import com.simdetails.entity.Simdetails;
import com.simdetails.repo.SimActivationRepo;


@Service
public class SimActivationService {
	@Autowired
	SimActivationRepo simRepo;
	
	@Autowired
	private DiscoveryClient client;
	
//	@Autowired
//	SimOffersRepo offersRepo; //microservices logic
	public String getOffers(String serviceNumber, String simNumber) throws InvalidSimDetailsException {
		//Exception needs to be handled here!
		Optional<Simdetails> sim = simRepo.findById(serviceNumber);
		if(sim.isPresent() && (sim.get().getServiceNumber().equals(serviceNumber) && sim.get().getSimNumber().equals(simNumber))) {
			Simdetails s = sim.get();	
			int simId = s.getSimId();
			if(s.getSimStatus().equals("active")) {
				return "SIM already active";
			}
			
			List<ServiceInstance> list = client.getInstances("simoffers");
			if(list!=null && !list.isEmpty()) {
				String uri = list.get(0).getUri().toString() + "/offer/"+ simId;
//				System.out.println(sim.get());
				simOffersDTO offer =  new RestTemplate().getForObject(uri, simOffersDTO.class);
				
				return "SimOffer [callQty=" + offer.getCallQty() + ", Cost=" + offer.getCost() + ", dataQty=" + offer.getDataQty()
						+ ", duration=" + offer.getDuration() + ", OfferName=" + offer.getOfferName() + "]";
			}
			else {
				throw new InvalidSimDetailsException("Invalid details, please check again SIM number/Service number!");
			}
		}
		else {
			throw new InvalidSimDetailsException("Invalid details, please check again SIM number/Service number!");
		}
	}
	
	public String activateSim(int simId){
		Simdetails sim = simRepo.findBySimId(simId).get();
		if(sim.getSimStatus().equals("active")) {
			return "SIM already active";
		}
		sim.setSimStatus("active");
		simRepo.saveAndFlush(sim);
		return "Sim activated Successfully";
	}
	
	
	
}
